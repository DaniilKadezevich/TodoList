'use strict';
let tasks = [];